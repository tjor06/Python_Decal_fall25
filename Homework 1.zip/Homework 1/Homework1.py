#File: Homework1.py
# --- Variables and Data Types ---
a = 10
print(a) 
print(type(a)) # a is an int, integer
b = 1.5
print(b)
print(type(b)) # b is a float, real number not in the set of integers
c = 3j
print(c)
print(type(c)) # c is a complex, a complex number
d = "hello"
print(d)
print(type(d)) # d is a str, a string, a collection of items (letters) in sequence
e = [1, 2, 3]
print(e)
print(type(e)) # e is a list, a list of things
f = {"name": "Ellen", "favorite fruit": "strawberry"}
print(f)
print(type(f)) # f is a dict, a dictionary, a group of strings
g = (1, 2)
print(g)
print(type(g)) # g is a tuple, an ordered and immutable sequence of elements
h = ["apple", "banana", "strawberry"]
print(h)
print(type(h)) # h is a list
i = True
print(i)
print(type(i)) #i is a bool, a boolean, elements that are representative of the trut or falisty of a condition of statement
j = None
print(j)
print(type(j)) #j is a NoneType, a datatype that represents the absence of a value
k = [True, "blue", 12]
print(k)
print(type(k)) # k is a list
l = str(14)
print(l)
print(type(l)) #l is a string, the number 14 represented as a string
m = 1e4
print(m)
print(type(m)) #m is a float, a real number that is not necessarily an integer

n = {1, "hi", 13, 1, "no"}
print(n)
print(type(n))

# Answer the following questions as comments below your variables.
# 1. How many different data types did you find? 9 different datatypes
# 2. List all the data types you found. int, float, complex, list, str, NoneType, bool, tuple, dict
# 3. What variables have the same data types? (b and m), (l and d), (k, h, and e)
# 4. What was the data type of l? Why is it not an integer? What does str() do? l is a string, and is not an integer because the code called str(14), which prints the string version of 14
# 5. Look up one more data type not given above. Repeat the same procedure

print(10 > 9) #True
print(10 == 9)#False
print(10 <= 9)#False
print(bool("abc")) #True
print(bool(123))#True
print(bool(["apple", "cherry", "banana"]))#True
print(bool(True))#True
print(bool(False))#False
print(bool(0))#False
print(bool(""))#False
print(bool(" "))#True
print(bool(()))#False
print(bool([]))#False

print(bool(True and False))#False
print(bool(True and True))#True
print(bool(False and False))#False
print(bool(True or False)) #True
print(bool(True or True)) #True
print(bool(False or False)) #False
print(bool(not(False))) #True
print(bool(not(True))) #False

print(10 + 5) # =15, addition
print(10 - 5) # = 5, subtracts
print(2 * 4) # = 8,multiplication
print(6 / 3) #=2.0, returns floats
print(5 % 2) # =1, gives the remainder
print(3 ** 2) # = 9, square of the first value
print(5 // 2) #2, rounds down to the nearest whole number 

print(5 == 2) #False, trivial
print(10 != 10)# False, != means not equal to
print(2 < 5) # True, true
print(12 > 5)#True
print(5 <= 6)#True
print(1 >= 10)# False, 1 is not more than 10

x = 5
x += 5 
print(x) # adds value to existing variable
x = 5
x -= 4 
print(x) #same, but subtracts
x = 5
x *= 3 
print(x) #same but multiplies. 


my_string = "hello" 
print(my_string) # Prints: hello 

print(my_string[0]) #h
print(my_string[1]) #e
print(my_string[2]) #l
print(my_string[3])#l
print(my_string[4]) #0
print(my_string[-1])#0
print(my_string[1:3])#el
print(my_string[0:5:2])#hlo 
print(len(my_string))#5
my_string += "goodbye"#hellogoodbye
print(my_string)
my_string = "hello"#
print(my_string * 7)# hellohellohellohellohellohello


name = "Oski" 
print("Hello, my name is", name) 
name = "Oski" 
print(f"Hello, my name is {name}") 



